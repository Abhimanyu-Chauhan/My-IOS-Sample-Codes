# MVVM Playground, a photo showcase app.

This is a sample code for MVVM playground. 

Please refer to 'MVC' to find the MVC version of the app.
And then please checke the latest code for the MVVM version with unit tests, it's cool!

